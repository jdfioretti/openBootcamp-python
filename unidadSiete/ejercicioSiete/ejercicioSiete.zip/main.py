from ejercicioSiete import operacionesMat

def main():
    res = operacionesMat.sumar(2,2)
    print('Hola')
    
if __name__== '__main__':
    main()