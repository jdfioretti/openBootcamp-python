from ejercicioSiete import operacionesMat


def main():
    operacionesMat.sumar(2, 2)


print(operacionesMat.sumar)

if __name__ == '__main__':
    main()
